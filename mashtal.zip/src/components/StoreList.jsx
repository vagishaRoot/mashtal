let JSON = [
    {
        key:1,
        Owner: "Al-Sheikh",
        Email: "alsheikh@gmail.com",
        Shop :"Indian Masala House",
        Category: "restaurant",
        Rating: 5
    },
    {
        key:2,
        Owner: "Al-Hashimi",
        Email: "alhashimi@gmail.com",
        Shop :"A.R Crafts",
        Category: "Other",
        Rating: 5
    },
    {
        key:3,
        Owner: "Arazi",
        Email: "arazi@gmail.com",
        Shop :"A&A Glam Bags",
        Category: "Cloth",
        Rating: 5
    },
    {
        key:4,
        Owner: "Assan",
        Email: "assan@gmail.com",
        Shop :"Amla Candy",
        Category: "Food",
        Rating: 5
    },
    {
        key:5,
        Owner: "Al-Sheikh",
        Email: "alsheikh@gmail.com",
        Shop :"Indian Masala House",
        Category: "restaurant",
        Rating: 5
    },
    {
        key:6,
        Owner: "Al-Hashimi",
        Email: "alhashimi@gmail.com",
        Shop :"A.R Crafts",
        Category: "Other",
        Rating: 5
    },
    {
        key:7,
        Owner: "Arazi",
        Email: "arazi@gmail.com",
        Shop :"A&A Glam Bags",
        Category: "Cloth",
        Rating: 5
    },
    {
        key:8,
        Owner: "Assan",
        Email: "assan@gmail.com",
        Shop :"Amla Candy",
        Category: "Food",
        Rating: 5
    },
    {
        key:9,
        Owner: "Al-Sheikh",
        Email: "alsheikh@gmail.com",
        Shop :"Indian Masala House",
        Category: "restaurant",
        Rating: 5
    },
    {
        key:10,
        Owner: "Al-Hashimi",
        Email: "alhashimi@gmail.com",
        Shop :"A.R Crafts",
        Category: "Other",
        Rating: 5
    },
    {
        key:11,
        Owner: "Arazi",
        Email: "arazi@gmail.com",
        Shop :"A&A Glam Bags",
        Category: "Cloth",
        Rating: 5
    },
    {
        key:12,
        Owner: "Assan",
        Email: "assan@gmail.com",
        Shop :"Amla Candy",
        Category: "Food",
        Rating: 5
    },
    {
        key:13,
        Owner: "Al-Sheikh",
        Email: "alsheikh@gmail.com",
        Shop :"Indian Masala House",
        Category: "restaurant",
        Rating: 5
    },
    {
        key:14,
        Owner: "Al-Hashimi",
        Email: "alhashimi@gmail.com",
        Shop :"A.R Crafts",
        Category: "Other",
        Rating: 5
    },
    {
        key:15,
        Owner: "Arazi",
        Email: "arazi@gmail.com",
        Shop :"A&A Glam Bags",
        Category: "Cloth",
        Rating: 5
    },
    {
        key:16,
        Owner: "Assan",
        Email: "assan@gmail.com",
        Shop :"Amla Candy",
        Category: "Food",
        Rating: 5
    },
    
]